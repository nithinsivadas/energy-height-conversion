function f = createFolder(this,foldername)
    % DEPRECATED, renamed as newFolder
    f = this.newFolder(foldername);
end